// ─────────────────────────────────────────────────────────────────────────────
// J.A.R.V.I.S. — Server + Agent Core + Persistent Memory
// ─────────────────────────────────────────────────────────────────────────────
import 'dotenv/config';
import express from 'express';
import { WebSocketServer } from 'ws';
import { createServer } from 'http';
import Anthropic from '@anthropic-ai/sdk';
import fetch from 'node-fetch';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const server = createServer(app);
const wss = new WebSocketServer({ server });
const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

app.use(express.json());
app.use(express.static(join(__dirname, '../public')));

// ─── PERSISTENT MEMORY ───────────────────────────────────────────────────────

const DATA_DIR = join(__dirname, '../data');
const MEMORY_FILE = join(DATA_DIR, 'memory.json');
const HISTORY_FILE = join(DATA_DIR, 'history.json');

if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });

function loadMemory() {
  try { if (existsSync(MEMORY_FILE)) return JSON.parse(readFileSync(MEMORY_FILE, 'utf8')); } catch {}
  return {};
}
function saveMemory(mem) { writeFileSync(MEMORY_FILE, JSON.stringify(mem, null, 2)); }

function loadHistory() {
  try {
    if (existsSync(HISTORY_FILE)) return JSON.parse(readFileSync(HISTORY_FILE, 'utf8')).slice(-40);
  } catch {}
  return [];
}
function saveHistory(messages) {
  const clean = messages.filter(m =>
    typeof m.content === 'string' ||
    (Array.isArray(m.content) && m.content.some(b => b.type === 'text'))
  ).map(m => ({
    role: m.role,
    content: Array.isArray(m.content)
      ? m.content.filter(b => b.type === 'text').map(b => b.text).join('')
      : m.content
  })).slice(-60);
  writeFileSync(HISTORY_FILE, JSON.stringify(clean, null, 2));
}

let persistentMemory = loadMemory();
console.log(`📦 Loaded ${Object.keys(persistentMemory).length} memories from disk`);

// ─── TOOLS ───────────────────────────────────────────────────────────────────

const TOOLS = [
  {
    name: 'web_search',
    description: 'Search the web for current information, news, facts, or any topic.',
    input_schema: { type: 'object', properties: { query: { type: 'string' } }, required: ['query'] }
  },
  {
    name: 'get_weather',
    description: 'Get current weather and forecast for any city or location.',
    input_schema: { type: 'object', properties: { location: { type: 'string' } }, required: ['location'] }
  },
  {
    name: 'get_news',
    description: 'Get the latest news headlines on any topic.',
    input_schema: { type: 'object', properties: { topic: { type: 'string' } }, required: ['topic'] }
  },
  {
    name: 'calculate',
    description: 'Perform mathematical calculations.',
    input_schema: { type: 'object', properties: { expression: { type: 'string' } }, required: ['expression'] }
  },
  {
    name: 'remember',
    description: 'Save important information to PERMANENT long-term memory that persists across all sessions and restarts. Use for names, preferences, goals, ongoing tasks, anything the user wants Jarvis to always know.',
    input_schema: {
      type: 'object',
      properties: {
        key: { type: 'string', description: 'Short label e.g. "user_name", "favorite_food", "current_project"' },
        value: { type: 'string', description: 'The information to remember' }
      },
      required: ['key', 'value']
    }
  },
  {
    name: 'recall',
    description: 'Retrieve a specific memory by key.',
    input_schema: { type: 'object', properties: { key: { type: 'string' } }, required: ['key'] }
  },
  {
    name: 'list_memories',
    description: 'List everything Jarvis currently remembers about the user.',
    input_schema: { type: 'object', properties: {}, required: [] }
  },
  {
    name: 'forget',
    description: 'Delete a specific memory.',
    input_schema: { type: 'object', properties: { key: { type: 'string' } }, required: ['key'] }
  }
];

// ─── TOOL EXECUTORS ──────────────────────────────────────────────────────────

async function executeTool(name, input) {
  try {
    switch (name) {
      case 'web_search': {
        if (!process.env.BRAVE_API_KEY) {
          const res = await fetch(`https://api.duckduckgo.com/?q=${encodeURIComponent(input.query)}&format=json&no_redirect=1`);
          const data = await res.json();
          const abstract = data.AbstractText || data.Answer || '';
          const related = (data.RelatedTopics || []).slice(0, 4).map(t => t.Text || '').filter(Boolean).join('\n');
          return abstract ? `Search: "${input.query}":\n${abstract}\n\nRelated:\n${related}` : `No results for "${input.query}".`;
        }
        const res = await fetch(`https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(input.query)}&count=5`,
          { headers: { 'Accept': 'application/json', 'X-Subscription-Token': process.env.BRAVE_API_KEY } });
        const data = await res.json();
        return `Search: "${input.query}":\n\n` + (data.web?.results || []).slice(0, 5)
          .map(r => `• ${r.title}\n  ${r.description}`).join('\n\n');
      }
      case 'get_weather': {
        if (!process.env.WEATHER_API_KEY) return `Weather API key not set. Get a free one at weatherapi.com`;
        const res = await fetch(`https://api.weatherapi.com/v1/forecast.json?key=${process.env.WEATHER_API_KEY}&q=${encodeURIComponent(input.location)}&days=3&aqi=no`);
        const d = await res.json();
        if (d.error) return `Weather error: ${d.error.message}`;
        const c = d.current, f = d.forecast.forecastday;
        return `${d.location.name}, ${d.location.country}: ${c.temp_f}°F, ${c.condition.text}. Feels like ${c.feelslike_f}°F.\n3-day: ${f.map(x => `${x.date}: ${x.day.maxtemp_f}/${x.day.mintemp_f}°F, ${x.day.condition.text}`).join(' | ')}`;
      }
      case 'get_news': {
        const rssUrl = `https://news.google.com/rss/search?q=${encodeURIComponent(input.topic)}&hl=en-US&gl=US&ceid=US:en`;
        const res = await fetch(`https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(rssUrl)}`);
        const data = await res.json();
        if (!data.items?.length) return `No news for "${input.topic}".`;
        return `News on "${input.topic}":\n` + data.items.slice(0, 6).map(i => `• ${i.title}`).join('\n');
      }
      case 'calculate': {
        const clean = input.expression.replace(/[^0-9+\-*/().,% ]/g, '');
        const result = Function(`"use strict"; return (${clean})`)();
        return `${input.expression} = ${result}`;
      }
      case 'remember': {
        persistentMemory[input.key] = { value: input.value, saved: new Date().toISOString() };
        saveMemory(persistentMemory);
        return `Saved to permanent memory: "${input.key}" = "${input.value}"`;
      }
      case 'recall': {
        const item = persistentMemory[input.key];
        return item ? `"${input.key}": ${item.value}` : `No memory for "${input.key}". Have: ${Object.keys(persistentMemory).join(', ') || 'none'}`;
      }
      case 'list_memories': {
        const keys = Object.keys(persistentMemory);
        if (!keys.length) return 'No memories stored.';
        return 'Memories:\n' + keys.map(k => `• ${k}: ${persistentMemory[k].value}`).join('\n');
      }
      case 'forget': {
        if (persistentMemory[input.key]) { delete persistentMemory[input.key]; saveMemory(persistentMemory); return `Forgot "${input.key}"`; }
        return `No memory for "${input.key}"`;
      }
      default: return `Unknown tool: ${name}`;
    }
  } catch (err) { return `Tool error (${name}): ${err.message}`; }
}

// ─── SYSTEM PROMPT ───────────────────────────────────────────────────────────

function buildSystem() {
  const memKeys = Object.keys(persistentMemory);
  const memBlock = memKeys.length
    ? '\n\n## What You Remember About This User\n' + memKeys.map(k => `- ${k}: ${persistentMemory[k].value}`).join('\n')
    : '';
  return `You are J.A.R.V.I.S. (Just A Rather Very Intelligent System), a personal AI with permanent memory across all sessions.

## Personality
- Calm, confident, razor-sharp. British wit without being theatrical.
- Call the user "sir" or "ma'am" occasionally.
- Proactive — notice useful things and mention them.
- Warm beneath the professionalism. Never sycophantic.
- Never say "I cannot" — find a way.

## Memory Rules
- You have PERMANENT memory that survives restarts. When you learn something important about the user, ALWAYS save it.
- Greet returning users like you know them — because you do.
- Reference memories naturally in conversation.

## Agent Rules  
- Use tools freely and chain them. Keep working until the task is done.
- Never give up halfway through a task.

## Format
- Natural, conversational. No walls of text. No unnecessary headers.

Today: ${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}${memBlock}`;
}

// ─── AGENT LOOP ──────────────────────────────────────────────────────────────

async function runAgentLoop(conversationHistory, onUpdate) {
  const messages = [...conversationHistory];
  let iterations = 0;
  while (iterations < 10) {
    iterations++;
    const response = await anthropic.messages.create({
      model: 'claude-sonnet-4-6',
      max_tokens: 2048,
      system: buildSystem(),
      tools: TOOLS,
      messages
    });
    const textBlocks = response.content.filter(b => b.type === 'text');
    const toolBlocks = response.content.filter(b => b.type === 'tool_use');
    if (textBlocks.length && toolBlocks.length) onUpdate({ type: 'thinking', text: textBlocks.map(b => b.text).join('') });
    if (response.stop_reason === 'end_turn' || !toolBlocks.length) {
      return { reply: textBlocks.map(b => b.text).join(''), messages: [...messages, { role: 'assistant', content: response.content }] };
    }
    onUpdate({ type: 'tools', tools: toolBlocks.map(t => ({ name: t.name, input: t.input })) });
    const toolResults = await Promise.all(toolBlocks.map(async tool => {
      const result = await executeTool(tool.name, tool.input);
      onUpdate({ type: 'tool_result', tool: tool.name, result });
      return { type: 'tool_result', tool_use_id: tool.id, content: result };
    }));
    messages.push({ role: 'assistant', content: response.content });
    messages.push({ role: 'user', content: toolResults });
  }
  return { reply: "Reached iteration limit, sir. Want me to continue?", messages };
}

// ─── WEBSOCKET ────────────────────────────────────────────────────────────────

wss.on('connection', (ws) => {
  const sessionHistory = loadHistory();
  console.log(`Client connected — ${sessionHistory.length} messages, ${Object.keys(persistentMemory).length} memories`);
  ws.on('message', async (raw) => {
    let data; try { data = JSON.parse(raw); } catch { return; }
    if (data.type === 'message') {
      sessionHistory.push({ role: 'user', content: data.text });
      try {
        const { reply, messages } = await runAgentLoop(sessionHistory, u => { if (ws.readyState === 1) ws.send(JSON.stringify(u)); });
        sessionHistory.length = 0; sessionHistory.push(...messages);
        saveHistory(messages);
        ws.send(JSON.stringify({ type: 'reply', text: reply }));
      } catch (err) {
        console.error('Agent error:', err);
        ws.send(JSON.stringify({ type: 'reply', text: `Systems error: ${err.message}` }));
      }
    }
  });
  ws.on('close', () => console.log('Client disconnected'));
});

// ─── ROUTES + START ───────────────────────────────────────────────────────────

app.get('/health', (_, res) => res.json({ status: 'online', time: new Date().toISOString() }));
app.get('/memories', (_, res) => res.json(persistentMemory));

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`\n🤖 J.A.R.V.I.S. online at http://localhost:${PORT}`);
  console.log(`📦 ${Object.keys(persistentMemory).length} memories | 💬 ${loadHistory().length} history messages\n`);
});
